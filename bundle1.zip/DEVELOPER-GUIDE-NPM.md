# Developer guide — Seal-patched dependencies (npm)

For projects with a `package.json`. If your project is Java, .NET or Go, use
the matching guide instead.

Your security team found dependencies in this project with known
vulnerabilities. Seal Security has produced patched versions of 15 npm packages
— **same package name, same base version, plus the CVE fixes**. Your job is to
move each one to its patched version.

**The patched packages are already in your Artifactory**, which your npm
registry already points at. There is nothing to download and no registry to
configure — the new versions are simply there.

**You do not change any application code.** No `require`/`import` changes, no
API changes. You edit the version in `package.json` and reinstall. Details in
[§6](#6-why-no-code-changes).

**The five steps**

| Step | What you do | Time |
|---|---|---|
| [1](#step-1--check-your-build-works-now) | Confirm your build is green *before* changing anything | your build |
| [2](#step-2--find-which-packages-apply-to-you) | Find which of the 15 your project actually uses | 2 min |
| [3](#step-3--edit-packagejson) | Change the version | 10 min |
| [4](#step-4--check-it-worked) | Check the patched package is really installed | 2 min |
| [5](#step-5--rebuild-test-commit) | Reinstall, test, commit | your build |

On Windows, open PowerShell: right-click the Start button → *Terminal* or
*Windows PowerShell*. Where a single unlabelled block appears, the command is
identical on all three platforms.

The screenshots are all taken on Windows.

---

## Step 1 — Check your build works now

Before changing anything, prove your project builds today. In your project
folder:

```
npm ci
npm run build
```

(If your project has no `build` script, run your test command instead.)

**If this fails, stop.** Fix it (or ask your team) before continuing —
otherwise you won't know whether a later failure was caused by your edit or was
already there.

---

## Step 2 — Find which packages apply to you

There are 15 patched packages. Find out which your project uses:

```
npm ls hammerjs tablesaw lodash.template ip js-yaml moment jquery-ui dompurify jquery elliptic
```

**Each package that comes back is one you'll deal with.** If nothing comes
back, your project uses none of the 15 — tell your security team and stop here.

| # | What you have now | What you switch to |
|---|---|---|
| 1 | `hammerjs@2.0.8` | `hammerjs@2.0.8-sp1` |
| 2 | `tablesaw@2.0.3` | `tablesaw@2.0.3-sp1` |
| 3 | `lodash.template@4.5.0` | `lodash.template@4.5.0-sp2` |
| 4 | `ip@1.1.5` | `ip@1.1.5-sp3` |
| 5 | `js-yaml@3.14.1` | `js-yaml@3.14.1-sp4` |
| 6 | `moment@2.24.0` | `moment@2.24.0-sp2` |
| 7 | `moment@2.27.0` | `moment@2.27.0-sp2` |
| 8 | `jquery-ui@1.12.1` | `jquery-ui@1.12.1-sp2p2` |
| 9 | `dompurify@3.4.4` | `dompurify@3.4.4-sp2` |
| 10 | `dompurify@3.4.5` | `dompurify@3.4.5-sp2` |
| 11 | `dompurify@3.4.6` | `dompurify@3.4.6-sp2` |
| 12 | `jquery@1.2.6` | `jquery@1.2.6-sp1p1` |
| 13 | `jquery@1.9.1` | `jquery@1.9.1-sp3p3` |
| 14 | `elliptic@6.5.2` | `elliptic@6.5.2-sp3` |
| 15 | `elliptic@6.5.4` | `elliptic@6.5.4-sp4` |

The version must match exactly. If you have `ip@1.1.5` and the table lists
`1.1.5`, that's a match. If you have `ip@1.1.9`, it is *not* — leave it alone.

Two things to notice in the `npm ls` output:

- **Is it yours or someone else's?** If the package is listed at the top level,
  it's a **direct** dependency — it's in your `package.json`. If it's nested
  under another package, it's **transitive**. Step 3 handles these differently.
- **`deduped`** next to an entry just means npm installed one copy that several
  packages share. Treat it as the same package.

---

## Step 3 — Edit `package.json`

Do **3a** for every direct dependency and **3b** for every transitive one.

### 3a — Direct dependencies (listed at the top level)

Change the version in `dependencies` (or `devDependencies`) to the exact
patched version, with **no range prefix**:

```json
{
  "dependencies": {
    "ip": "1.1.5-sp3"
  }
}
```

> **Drop the `^` or `~`.** npm treats `-sp3` as a *prerelease*, and a range
> like `^1.1.5` deliberately does not match prereleases — so `^1.1.5-sp3` will
> not do what you expect, and `^1.1.5` will quietly reinstall the vulnerable
> version. Write the version on its own.

### 3b — Transitive dependencies (nested under another package)

You can't edit a version you don't declare. Add an `overrides` block to your
**root** `package.json`. **Put the version in the key**, so the override applies
only to the version Seal patched:

```json
{
  "overrides": {
    "lodash.template@4.5.0": "4.5.0-sp2"
  }
}
```

Add one entry per transitive package. If your `package.json` already has an
`overrides` key, add into the existing one rather than creating a second.

> **Don't write the key as just `"lodash.template"`.** Unlike Java or .NET, an
> npm tree can hold several copies of the same package at different versions. A
> key with no version means *every* copy, anywhere in the tree — so a
> `lodash.template@3.x` that some unrelated library depends on would also be
> dragged to `4.5.0-sp2`. Seal patched one version; override that one.

> `overrides` needs **npm 8.3 or newer** — check with `npm -v`. On Yarn the
> equivalent key is `resolutions`; on pnpm it's `pnpm.overrides`.

> **The version in the key is matched against what each package *asks for*, not
> against what npm resolved.** So a library depending on `^4.0.0` is covered by
> the `@4.5.0` key too, because that range includes 4.5.0. That's usually what
> you want — it's the same package moving to the patched build — but it does
> mean such a library can shift by a patch version. Step 4 shows you exactly
> what changed.

---

## Step 4 — Check it worked

Reinstall so the lockfile is regenerated, then ask npm what it actually
installed:

```
npm install
npm ls hammerjs tablesaw lodash.template ip js-yaml moment jquery-ui dompurify jquery elliptic
```

![npm ls showing the patched -sp versions installed](img/npm-verify-local.png)

**Every package you changed should show its `-sp` version.** If one still shows
the old version:

- for a direct dependency, you probably left a `^` or `~` in front of it;
- for a transitive one, the `overrides` entry is missing, its key is a version
  the package never asked for, or it isn't in the **root** `package.json`.

If npm refuses to reconcile the lockfile, delete `node_modules` and
`package-lock.json` and run `npm install` again.

---

## Step 5 — Rebuild, test, commit

```
npm run build
npm test
```

Then run whatever smoke test you'd normally run before a release. You're
checking that the patch didn't change behaviour your code depends on — see
[§6](#6-why-no-code-changes) for why that's unlikely but worth confirming.

Commit **`package.json` and `package-lock.json`**. Both matter: the lockfile is
what pins the patched version for everyone else. Suggested commit message:

```
Move vulnerable dependencies to Seal-patched versions
```

That's the whole job.

---

## 6. Why no code changes

Seal's patches are **backports**: the security fix from the upstream project is
applied on top of the version you already run, without pulling in the rest of
the newer release.

That means:

- The public API is unchanged — same exports, same signatures.
- The package name is unchanged — no `require`/`import` changes.
- Everything that resolved before still resolves, at the same versions.

The only difference you can see from the outside is the version string.

---

## 7. When something goes wrong

| What you see | What it means | What to do |
|---|---|---|
| `No matching version found for ip@1.1.5-sp3` | Your npm cache has a stale index, or Artifactory hasn't picked up the new versions yet | Run `npm cache clean --force` and retry. If it still fails, the version isn't in Artifactory yet — tell your security team which package is missing |
| `npm ls` still shows the old version | A `^` or `~` is still in front of the version, or the `overrides` key is missing its `@version` | Pin the exact version (3a); check the override key reads `lodash.template@4.5.0`, not just `lodash.template` (3b) |
| `overrides` seems to be ignored | npm older than 8.3, or the key isn't in the root `package.json` | Check `npm -v`; move the key to the root |
| `npm ci` fails with a lockfile mismatch | `package.json` and `package-lock.json` disagree after your edit | Run `npm install` (not `ci`) once to regenerate the lockfile, then commit both |
| A test fails after the change | Worth a real look — but check first whether it fails on the *unmodified* project too (Step 1) | If it fails both ways it isn't related to the patch. If it only fails after, tell your security team which package and which test |

**One package at a time.** If you have several to do and something breaks, redo
them one at a time — change one version, run Step 4 and Step 5, then move to the
next.

---

## 8. Reference — the version suffixes

| Suffix | Meaning |
|---|---|
| `-sp1`, `-sp2`, `-sp3` | Seal patch wave 1, 2 or 3 applied on top of the base version |

npm reads these as ordinary prerelease versions — which is why they must be
written exactly, without a `^` or `~` range prefix.

---

## Questions

If you get stuck, send your security team:

- the output of the Step 2 discovery command,
- the output of the Step 4 verification command,
- and the error, in full.

That's almost always enough to answer it without a call.
