# Loading the Seal bundle into Artifactory

Four scripts, one per ecosystem. They read the unzipped bundle and
`PUT` each artifact into an Artifactory repository. Run them once, before the
developer guides in the folder above are handed out — those guides assume
everything is already there.

| Script | Reads | Uploads |
|---|---|---|
| `upload-maven.sh` | `packages-java/` | 66 jars + 66 poms (132 files) |
| `upload-npm.sh` | `packages-npm/` | 13 tarballs |
| `upload-nuget.sh` | `packages-nuget/` | 2 `.nupkg` |
| `upload-go.sh` | `packages-go/` | 17 modules × 3 files (51 files) |

They run in **Git Bash on Windows**, and unchanged on macOS/Linux. `curl` is the
only hard requirement; `upload-npm.sh` also uses `tar`, and `upload-go.sh` needs
one of `unzip` / `bsdtar` / `python3` to read `go.mod` out of the module zips
(Windows' own `C:\Windows\System32\tar.exe` counts, and is tried automatically).

## Before you start

The bundle comes as three zips — `-java`, `-go` and `-npm-nuget` — each with
its own packages and its own upload script(s). Unzip them all into the **same
folder** (they don't overlap), so the commands below work as written.

Then create four **local** repositories in
Artifactory — one per package type (Maven, npm, NuGet, Go). Remote or virtual
repositories won't accept a deploy.

## Running them

```bash
export ART_URL=https://artifactory.example.com/artifactory
export ART_TOKEN=<identity-token>          # or ART_USER + ART_PASSWORD

ART_REPO=seal-maven-local ./upload-maven.sh  ~/Downloads/seal-bundle
ART_REPO=seal-npm-local   ./upload-npm.sh    ~/Downloads/seal-bundle
ART_REPO=seal-nuget-local ./upload-nuget.sh  ~/Downloads/seal-bundle
ART_REPO=seal-go-local    ./upload-go.sh     ~/Downloads/seal-bundle
```

The bundle path is optional. Each script locates the bundle from **its own
location** — the parent of the `upload/` folder it sits in — not from your
working directory, so any of these do the same thing:

```bash
cd ~/Downloads/seal-bundle &&  ./upload/upload-maven.sh   # from the bundle root
cd ~/Downloads/seal-bundle/upload && ./upload-maven.sh    # from inside upload/
~/Downloads/seal-bundle/upload/upload-maven.sh            # from anywhere
```

Pass the path explicitly only if you've copied a script out of the bundle —
on its own it will look for `packages-java/` next to wherever you put it and
stop with `ERROR: no packages-java/ under <path>`.

| Variable | Meaning |
|---|---|
| `ART_URL` | Base URL **including** `/artifactory` |
| `ART_REPO` | Target repository key — different for each script |
| `ART_TOKEN` | Identity token, sent as `Authorization: Bearer` |
| `ART_USER` + `ART_PASSWORD` | Basic auth, if you aren't using a token |

Two flags on every script:

- `--dry-run` — print what would be uploaded and exit. Start here.
- `--force` — re-upload files that are already in the repository.

Each script prints one line per file, ends with an
`uploaded / skipped / failed` summary, and **exits non-zero if anything
failed** — so it can go straight into a pipeline.

**They are safe to re-run.** Every file is checked with a `HEAD` first and
skipped if it's already there, so an interrupted run can simply be repeated.
Where `sha1sum` is available the upload also sends an `X-Checksum-Sha1` header,
so Artifactory rejects a corrupted transfer instead of storing it.

## What each script does with the paths

**Maven** — `packages-java/` is already a Maven repository layout, so it's a
straight mirror. **Both the jar and its `.pom` go up** — 132 files, not 66:

```
packages-java/seal/sp2/log4j/log4j/1.2.17/log4j-1.2.17.jar
  -> $ART_URL/$ART_REPO/seal/sp2/log4j/log4j/1.2.17/log4j-1.2.17.jar
packages-java/seal/sp2/log4j/log4j/1.2.17/log4j-1.2.17.pom
  -> $ART_URL/$ART_REPO/seal/sp2/log4j/log4j/1.2.17/log4j-1.2.17.pom
```

The pom is not optional. A jar deployed without one still resolves, but Maven
then sees no dependencies for it and silently drops the artifact's entire
transitive subtree — a build that compiles and fails at runtime. The script
checks every jar has a companion pom *before* uploading anything, and refuses
to run if one is missing.

Each pom declares the renamed GAV that matches its deploy path, so Artifactory
accepts them with POM consistency checks left on.

**npm** — the package name and version are read from the `package.json` *inside*
each tarball, not parsed from the filename (`lodash.template-4.5.0-sp2.tgz`
can't be split into name and version by eye):

```
lodash.template-4.5.0-sp2.tgz
  -> $ART_URL/$ART_REPO/lodash.template/-/lodash.template-4.5.0-sp2.tgz
```

**NuGet** — deployed to the repository root; Artifactory reads the id and
version from the `.nuspec` inside and indexes it.

**Go** — a module is three files on a proxy, not one. The script uploads the
zip, the `.mod` extracted from inside it, and a generated `.info`:

```
packages-go/github.com/smartystreets/goconvey/v1.6.4-sp1.zip
  -> $ART_URL/$ART_REPO/github.com/smartystreets/goconvey/@v/v1.6.4-sp1.zip
  -> ...                                                  /v1.6.4-sp1.mod
  -> ...                                                  /v1.6.4-sp1.info
```

One module in the bundle — the oldest `golang.org/x/tools` revision — predates
`go.mod` and has none inside its zip. For that one the script synthesises a
minimal `module golang.org/x/tools`, which is what the Go toolchain does for
pre-modules code anyway. It says so in its output when it happens.

## Checking it landed

```bash
# Maven — expect 200
curl -I -H "Authorization: Bearer $ART_TOKEN" \
  "$ART_URL/seal-maven-local/seal/sp2/log4j/log4j/1.2.17/log4j-1.2.17.jar"

# npm
npm view ip@1.1.5-sp3 --registry "$ART_URL/api/npm/seal-npm-local/"

# Go
GOPROXY="$ART_URL/api/go/seal-go-local" GOSUMDB=off \
  go list -m github.com/smartystreets/goconvey@v1.6.4-sp1
```

For NuGet, search for `jQuery` with prerelease versions included — `3.3.1-sp1p1`
sorts *below* `3.3.1`, so it's hidden by default.

## If a script reports failures

The HTTP status and Artifactory's response body are printed for each failure.
The usual causes:

| Status | Cause |
|---|---|
| `401` / `403` | Token expired, or it lacks deploy permission on that repository |
| `404` | `ART_URL` is missing `/artifactory`, or `ART_REPO` doesn't exist |
| `405` | The target is a remote or virtual repository — deploy needs a local one |
| `409` | A checksum mismatch: the file arrived corrupted. Re-run with `--force` |
| `000` | curl couldn't reach the host at all — proxy or DNS |
| `curl: Can't open '/c/Users/...'` | An older copy of the script, on Git Bash. Git Bash runs a native Windows curl that can't read MSYS paths. Use a current copy, or pass the bundle as a Windows path: `./upload-maven.sh 'C:/Users/you/seal-bundle'` |
