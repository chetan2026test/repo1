#!/usr/bin/env bash
# upload-npm.sh — load the 13 patched npm packages from the Seal bundle into an
# Artifactory npm repository.
#
# Runs in Git Bash on Windows, and in bash on macOS/Linux. Needs curl and tar.
#
#   ART_URL=https://artifactory.example.com/artifactory \
#   ART_REPO=seal-npm-local \
#   ART_TOKEN=<identity-token> \
#     ./upload-npm.sh ~/Downloads/seal-bundle
#
# The package name and version are read out of each tarball's package.json
# rather than parsed from the filename — "lodash.template-4.5.0-sp2.tgz" cannot
# be split into name and version reliably by eye.
#
#   lodash.template-4.5.0-sp2.tgz
#     -> $ART_URL/$ART_REPO/lodash.template/-/lodash.template-4.5.0-sp2.tgz
#
# Safe to re-run: files already in the repo are skipped unless --force.

set -uo pipefail
export MSYS_NO_PATHCONV=1   # URLs pass through verbatim; see winpath below

DRY_RUN=0
FORCE=0
BUNDLE=""

usage() {
    sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'
    echo
    echo "Options:"
    echo "  --dry-run   list what would be uploaded, upload nothing"
    echo "  --force     re-upload even if the file is already in the repo"
    exit "${1:-0}"
}

while [ $# -gt 0 ]; do
    case "$1" in
        --dry-run) DRY_RUN=1 ;;
        --force)   FORCE=1 ;;
        -h|--help) usage 0 ;;
        -*)        echo "unknown option: $1" >&2; usage 1 ;;
        *)         BUNDLE="$1" ;;
    esac
    shift
done

: "${ART_URL:?set ART_URL, e.g. https://artifactory.example.com/artifactory}"
: "${ART_REPO:?set ART_REPO, e.g. seal-npm-local}"
ART_URL="${ART_URL%/}"

AUTH=()
if [ -n "${ART_TOKEN:-}" ]; then
    AUTH=(-H "Authorization: Bearer $ART_TOKEN")
elif [ -n "${ART_USER:-}" ] && [ -n "${ART_PASSWORD:-}" ]; then
    AUTH=(-u "$ART_USER:$ART_PASSWORD")
else
    echo "ERROR: set ART_TOKEN, or both ART_USER and ART_PASSWORD" >&2
    exit 2
fi

[ -n "$BUNDLE" ] || BUNDLE="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$BUNDLE/packages-npm"
[ -d "$SRC" ] || { echo "ERROR: no packages-npm/ under $BUNDLE" >&2; exit 2; }

command -v curl >/dev/null || { echo "ERROR: curl not found" >&2; exit 2; }

# ---------------------------------------------------------------------------
# Windows path handling.
#
# Git Bash runs a native Windows curl.exe, which cannot open an MSYS-style path
# such as /c/Users/you/file.jar — it wants C:/Users/you/file.jar. MSYS normally
# rewrites such arguments on the way to a native program, but MSYS_NO_PATHCONV
# above turns that off so the URLs pass through untouched. So convert the two
# arguments that need it ourselves, and leave everything else alone.
#
# On macOS/Linux there is no cygpath, both are already correct, and these are
# no-ops.
# ---------------------------------------------------------------------------
if command -v cygpath >/dev/null 2>&1; then
    DEVNULL=NUL                       # /dev/null means nothing to Windows curl
    winpath() { cygpath -m "$1"; }    # -m: C:/Users/... (forward slashes)
else
    DEVNULL=/dev/null
    winpath() { printf '%s' "$1"; }
fi
command -v tar  >/dev/null || { echo "ERROR: tar not found"  >&2; exit 2; }

# Pull one field out of the package.json inside a .tgz. npm tarballs always
# root everything under "package/".
tgz_field() {
    # The archive is fed on stdin rather than named as an argument: tar reads a
    # leading "C:" in a filename as a remote host spec (host:path), so a Windows
    # path like C:/Users/you/ip-1.1.5-sp3.tgz makes it try to reach a machine
    # called "C" and fail. Shell redirection has no such quirk.
    tar -xzOf - package/package.json < "$1" 2>/dev/null \
        | tr -d ' \t' \
        | grep -m1 "\"$2\":" \
        | sed -E 's/.*"'"$2"'":"([^"]+)".*/\1/'
}

echo "Source: $SRC"
echo "Target: $ART_URL/$ART_REPO/"
[ "$DRY_RUN" = 1 ] && echo "(dry run — nothing will be uploaded)"
echo

ok=0; skipped=0; failed=0

while IFS= read -r -d '' file; do
    base="$(basename "$file")"
    name="$(tgz_field "$file" name)"
    ver="$(tgz_field "$file" version)"

    if [ -z "$name" ] || [ -z "$ver" ]; then
        printf '  FAILED        %s (could not read name/version from package.json)\n' "$base" >&2
        failed=$((failed + 1))
        continue
    fi

    url="$ART_URL/$ART_REPO/$name/-/$base"

    if [ "$DRY_RUN" = 1 ]; then
        printf '  would upload  %-34s -> %s@%s\n' "$base" "$name" "$ver"
        ok=$((ok + 1))
        continue
    fi

    if [ "$FORCE" = 0 ]; then
        code=$(curl -s -o "$DEVNULL" -w '%{http_code}' -I "${AUTH[@]}" "$url")
        if [ "$code" = "200" ]; then
            printf '  skip          %-34s (already there)\n' "$base"
            skipped=$((skipped + 1))
            continue
        fi
    fi

    sums=()
    command -v sha1sum >/dev/null && \
        sums+=(-H "X-Checksum-Sha1: $(sha1sum "$file" | cut -d' ' -f1)")

    body=$(curl -s -w '\n%{http_code}' -X PUT "${AUTH[@]}" "${sums[@]}" \
                --upload-file "$(winpath "$file")" "$url")
    code="${body##*$'\n'}"
    case "$code" in
        20*) printf '  uploaded      %-34s -> %s@%s\n' "$base" "$name" "$ver"; ok=$((ok + 1)) ;;
        *)   printf '  FAILED  (%s)  %s\n' "$code" "$base" >&2
             printf '          %s\n' "${body%$'\n'*}" >&2
             failed=$((failed + 1)) ;;
    esac
done < <(find "$SRC" -type f -name '*.tgz' -print0 | sort -z)

echo
echo "uploaded: $ok   skipped: $skipped   failed: $failed"
echo
echo "Verify with:  npm view ip@1.1.5-sp3 --registry $ART_URL/api/npm/$ART_REPO/"
[ "$failed" -eq 0 ] || exit 1
