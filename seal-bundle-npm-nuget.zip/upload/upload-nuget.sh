#!/usr/bin/env bash
# upload-nuget.sh — load the patched NuGet packages from the Seal bundle into an
# Artifactory NuGet repository.
#
# Runs in Git Bash on Windows, and in bash on macOS/Linux. Needs curl only.
#
#   ART_URL=https://artifactory.example.com/artifactory \
#   ART_REPO=seal-nuget-local \
#   ART_TOKEN=<identity-token> \
#     ./upload-nuget.sh ~/Downloads/seal-bundle
#
# The bundle ships one package, jQuery 3.3.1-sp1p1. It is deployed to the root
# of the repository; Artifactory reads the id and version out of the .nuspec
# inside and indexes it:
#
#   jquery.3.3.1-sp1p1.nupkg -> $ART_URL/$ART_REPO/jquery.3.3.1-sp1p1.nupkg
#
# Safe to re-run: files already in the repo are skipped unless --force.

set -uo pipefail
export MSYS_NO_PATHCONV=1   # URLs pass through verbatim; see winpath below

DRY_RUN=0
FORCE=0
BUNDLE=""

usage() {
    sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'
    echo
    echo "Options:"
    echo "  --dry-run   list what would be uploaded, upload nothing"
    echo "  --force     re-upload even if the file is already in the repo"
    exit "${1:-0}"
}

while [ $# -gt 0 ]; do
    case "$1" in
        --dry-run) DRY_RUN=1 ;;
        --force)   FORCE=1 ;;
        -h|--help) usage 0 ;;
        -*)        echo "unknown option: $1" >&2; usage 1 ;;
        *)         BUNDLE="$1" ;;
    esac
    shift
done

: "${ART_URL:?set ART_URL, e.g. https://artifactory.example.com/artifactory}"
: "${ART_REPO:?set ART_REPO, e.g. seal-nuget-local}"
ART_URL="${ART_URL%/}"

AUTH=()
if [ -n "${ART_TOKEN:-}" ]; then
    AUTH=(-H "Authorization: Bearer $ART_TOKEN")
elif [ -n "${ART_USER:-}" ] && [ -n "${ART_PASSWORD:-}" ]; then
    AUTH=(-u "$ART_USER:$ART_PASSWORD")
else
    echo "ERROR: set ART_TOKEN, or both ART_USER and ART_PASSWORD" >&2
    exit 2
fi

[ -n "$BUNDLE" ] || BUNDLE="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$BUNDLE/packages-nuget"
[ -d "$SRC" ] || { echo "ERROR: no packages-nuget/ under $BUNDLE" >&2; exit 2; }

command -v curl >/dev/null || { echo "ERROR: curl not found" >&2; exit 2; }

# ---------------------------------------------------------------------------
# Windows path handling.
#
# Git Bash runs a native Windows curl.exe, which cannot open an MSYS-style path
# such as /c/Users/you/file.jar — it wants C:/Users/you/file.jar. MSYS normally
# rewrites such arguments on the way to a native program, but MSYS_NO_PATHCONV
# above turns that off so the URLs pass through untouched. So convert the two
# arguments that need it ourselves, and leave everything else alone.
#
# On macOS/Linux there is no cygpath, both are already correct, and these are
# no-ops.
# ---------------------------------------------------------------------------
if command -v cygpath >/dev/null 2>&1; then
    DEVNULL=NUL                       # /dev/null means nothing to Windows curl
    winpath() { cygpath -m "$1"; }    # -m: C:/Users/... (forward slashes)
else
    DEVNULL=/dev/null
    winpath() { printf '%s' "$1"; }
fi

echo "Source: $SRC"
echo "Target: $ART_URL/$ART_REPO/"
[ "$DRY_RUN" = 1 ] && echo "(dry run — nothing will be uploaded)"
echo

ok=0; skipped=0; failed=0

while IFS= read -r -d '' file; do
    base="$(basename "$file")"
    url="$ART_URL/$ART_REPO/$base"

    if [ "$DRY_RUN" = 1 ]; then
        printf '  would upload  %s\n' "$base"
        ok=$((ok + 1))
        continue
    fi

    if [ "$FORCE" = 0 ]; then
        code=$(curl -s -o "$DEVNULL" -w '%{http_code}' -I "${AUTH[@]}" "$url")
        if [ "$code" = "200" ]; then
            printf '  skip          %s (already there)\n' "$base"
            skipped=$((skipped + 1))
            continue
        fi
    fi

    sums=()
    command -v sha1sum >/dev/null && \
        sums+=(-H "X-Checksum-Sha1: $(sha1sum "$file" | cut -d' ' -f1)")

    body=$(curl -s -w '\n%{http_code}' -X PUT "${AUTH[@]}" "${sums[@]}" \
                --upload-file "$(winpath "$file")" "$url")
    code="${body##*$'\n'}"
    case "$code" in
        20*) printf '  uploaded      %s\n' "$base"; ok=$((ok + 1)) ;;
        *)   printf '  FAILED  (%s)  %s\n' "$code" "$base" >&2
             printf '          %s\n' "${body%$'\n'*}" >&2
             failed=$((failed + 1)) ;;
    esac
done < <(find "$SRC" -type f -name '*.nupkg' -print0 | sort -z)

echo
echo "uploaded: $ok   skipped: $skipped   failed: $failed"
echo
echo "The package is a prerelease (3.3.1-sp1p1). Consumers must tick"
echo "\"Include prerelease\" in the Visual Studio UI, or pin the exact version."
[ "$failed" -eq 0 ] || exit 1
