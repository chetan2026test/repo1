# Developer guide — Seal-patched dependencies (NuGet)

For .NET projects that get **jQuery** or **Ember** from NuGet. If your project is Java, npm
or Go, use the matching guide instead.

Your security team found jQuery 3.3.1 or Ember 1.0.0-rc1 in this project, and
it has known vulnerabilities. Seal Security has produced patched versions —
**same package id, same base version, plus the CVE fixes**. Your job is to move
to them.

**The patched packages are already in your Artifactory**, which your NuGet feed
already points at. There is nothing to download and no package source to add —
the new versions are simply there.

**You do not change any application code.** No `<script src=...>` changes, no
API changes, and the script filenames on disk are identical. Details in
[§6](#6-why-no-code-changes).

**The five steps**

| Step | What you do | Time |
|---|---|---|
| [1](#step-1--check-your-build-works-now) | Confirm your build is green *before* changing anything | your build |
| [2](#step-2--find-out-whether-it-applies-to-you) | Confirm this project really uses jQuery 3.3.1 or Ember 1.0.0-rc1 | 2 min |
| [3](#step-3--switch-to-the-patched-version) | Change the version | 5 min |
| [4](#step-4--check-it-worked) | Check the patched package is really on disk | 2 min |
| [5](#step-5--rebuild-test-commit) | Rebuild, test, commit | your build |

On Windows, open PowerShell: right-click the Start button → *Terminal* or
*Windows PowerShell*. Where a single unlabelled block appears, the command is
identical on all platforms.

The screenshots are all taken on Windows.

---

## Step 1 — Check your build works now

Before changing anything, prove your project builds today. In your project
folder:

```
dotnet build
```

![dotnet build succeeding on the unmodified project](img/nuget-baseline.png)

For older projects that don't use the `dotnet` CLI, build from a **Developer
Command Prompt for Visual Studio**. This is Windows-only — .NET Framework
projects of the kind that consume jQuery from NuGet don't build on macOS or
Linux:

```
msbuild /t:Rebuild
```

**If this fails, stop.** Fix it (or ask your team) before continuing —
otherwise you won't know whether a later failure was caused by your change or
was already there.

---

## Step 2 — Find out whether it applies to you

Search your project for jQuery and Ember:

**Windows (PowerShell)**

```powershell
Select-String -Path .\packages.config,.\*.csproj -Pattern 'jQuery|Ember' -ErrorAction SilentlyContinue
dir -Recurse -Include 'jquery-*.js','ember-*.js' | Select-Object Name
```

**macOS / Linux**

```bash
grep -lE 'jQuery|Ember' packages.config *.csproj 2>/dev/null
find . -name 'jquery-*.js' -o -name 'ember-*.js'
```

![The discovery commands showing jQuery 3.3.1 in packages.config and the Scripts folder](img/nuget-discovery.png)

### The 2 patched packages

| # | What you have now | What you switch to |
|---|---|---|
| 1 | `jQuery` `3.3.1` | `jQuery` `3.3.1-sp1p1` |
| 2 | `Ember` `1.0.0-rc1` | `Ember` `1.0.0-rc1-sp1` |

**The version must match exactly.** If you have jQuery 3.4.1, 3.6.0 or 1.x,
that is *not* a match — leave it alone and tell your security team. The same
goes for Ember: only `1.0.0-rc1` matches.

---

## Step 3 — Switch to the patched version

Which of the two you do depends on how your project references packages. Look
at your project folder: if there's a `packages.config`, use **3a**; if the
versions live in the `.csproj` as `<PackageReference>`, use **3b**.

### 3a — `packages.config` projects

From the **Package Manager Console** in Visual Studio (*Tools → NuGet Package
Manager → Package Manager Console*):

```powershell
Install-Package jQuery -Version 3.3.1-sp1p1
Install-Package Ember -Version 1.0.0-rc1-sp1
```

Run only the line for the package your project has.

This removes the old version, installs the patched one, updates
`packages.config` and refreshes the scripts under `Scripts\`.

Your `packages.config` should end up with:

```xml
<package id="jQuery" version="3.3.1-sp1p1" targetFramework="net472" />
<package id="Ember" version="1.0.0-rc1-sp1" targetFramework="net472" />
```

### 3b — `PackageReference` projects

Edit the `.csproj` and pin the exact version in square brackets:

```xml
<PackageReference Include="jQuery" Version="[3.3.1-sp1p1]" />
<PackageReference Include="Ember" Version="[1.0.0-rc1-sp1]" />
```

Then restore:

```
dotnet restore
```

> **Use the square brackets.** They mean *exactly this version*. NuGet sorts
> `3.3.1-sp1p1` **below** plain `3.3.1`, because anything after a `-` is a
> prerelease — so an unpinned `3.3.1` reference, or anything that offers to
> "update jQuery", will quietly take you back to the vulnerable version. The
> brackets stop that.

> **`PackageReference` and content files.** jQuery ships its scripts as package
> *content*, and `PackageReference` projects don't copy content into the
> project folder the way `packages.config` does. If your pages load jQuery from
> `Scripts\`, those files come from the package restore folder — check Step 4
> against the file your pages actually reference.

---

## Step 4 — Check it worked

The patched script carries `sp1p1` in its banner comment. That is how you
confirm the file your pages load is the patched one:

**Windows (PowerShell)**

```powershell
Select-String -Path .\Scripts\jquery-3.3.1*.js -Pattern 'sp1p1'
```

**macOS / Linux**

```bash
grep -l 'sp1p1' Scripts/jquery-3.3.1*.js
```

![the patched jQuery files matching on sp1p1](img/nuget-verify.png)

You should get a hit for `jquery-3.3.1.js` and `jquery-3.3.1.min.js`.

**If you get no hit, the old file is still there.** Check every copy in the
project, not just the one in `Scripts\`:

**Windows (PowerShell)**

```powershell
dir -Recurse -Filter 'jquery-3.3.1*.js' | ForEach-Object {
  "{0,-46} {1}" -f $_.Name, (Select-String -Path $_.FullName -Pattern 'sp1p1' -Quiet)
}
```

**macOS / Linux**

```bash
find . -name 'jquery-3.3.1*.js' -exec sh -c 'printf "%-46s %s\n" "$1" "$(grep -c sp1p1 "$1")"' _ {} \;
```

Every copy that your application actually serves must be a patched one.

### Ember

The Ember scripts carry no marker in the file, so check the version instead.
For `packages.config` projects, confirm the patched version is recorded and
that the script in `Scripts\` is the one from the patched package:

**Windows (PowerShell)**

```powershell
Select-String -Path .\packages.config -Pattern 'Ember'
Get-FileHash .\Scripts\ember-1.0.0-rc.1.js, .\packages\Ember.1.0.0-rc1-sp1\Content\Scripts\ember-1.0.0-rc.1.js
```

**macOS / Linux**

```bash
grep 'Ember' packages.config
shasum Scripts/ember-1.0.0-rc.1.js packages/Ember.1.0.0-rc1-sp1/Content/Scripts/ember-1.0.0-rc.1.js
```

The first command should show `1.0.0-rc1-sp1`, and the two hashes should be
identical. For `PackageReference` projects, `dotnet list package` should show
Ember at `1.0.0-rc1-sp1`.

---

## Step 5 — Rebuild, test, commit

```
dotnet build
```

(or `msbuild /t:Rebuild` from the Developer Command Prompt.)

Then load a page in the browser and confirm jQuery or Ember still works — the patch
doesn't change the API, but a smoke test costs a minute.

Commit:

- `packages.config` or the `.csproj` — whichever you edited;
- the refreshed `Scripts\jquery-3.3.1*.js` or `Scripts\ember-1.0.0-rc.1*.js`
  files, **if** your repository tracks them (many `packages.config` projects do).

Suggested commit message:

```
Move jQuery / Ember to the Seal-patched version
```

That's the whole job.

---

## 6. Why no code changes

Seal's patch is a **backport**: the security fix from upstream is applied on top
of the version you already use (jQuery 3.3.1, Ember 1.0.0-rc1), without pulling
in the rest of a newer release. The table below uses jQuery; Ember is the same,
except that its scripts carry no marker (see Step 4).

| | Changes? |
|---|---|
| the version in `packages.config` / `.csproj` | **Yes** — `3.3.1` → `3.3.1-sp1p1` |
| the package id | No — still `jQuery` |
| the `jquery-3.3.1*.js` file names | No — identical |
| your `<script src="...">` tags | No |
| your `BundleConfig` entries | No |
| the jQuery API your code calls | No |

The filenames deliberately stay the same so nothing that references them has to
change. The `sp1p1` marker lives inside the file, in the banner comment — which
is what Step 4 checks.

---

## 7. When something goes wrong

| What you see | What it means | What to do |
|---|---|---|
| `Unable to find package jQuery with version (= 3.3.1-sp1p1)` | Your NuGet cache has a stale index, or Artifactory hasn't picked up the new version yet | Run `dotnet nuget locals http-cache --clear` and retry. If it still fails, the version isn't in Artifactory yet — tell your security team |
| NuGet offers to "update jQuery to 3.3.1" | Expected — `3.3.1-sp1p1` sorts *below* `3.3.1` | Decline it. Pin with square brackets (3b) so it can't happen silently |
| Step 4 finds no `sp1p1` | The old script files are still on disk, or your pages load a copy from somewhere else | Search the whole project with the recursive command in Step 4 |
| Visual Studio doesn't offer the version in the UI | The Package Manager UI hides prereleases by default | Tick **Include prerelease**, or use the Package Manager Console command in 3a |
| The page breaks after the change | Worth a real look — but check first whether it breaks on the *unmodified* project too (Step 1) | If it breaks both ways it isn't related to the patch. If only after, tell your security team what broke |

---

## 8. Reference — the version suffix

| Suffix | Meaning |
|---|---|
| `-sp1` | Seal patch wave 1 |
| `-sp1p1` | Seal patch wave 1, from a build produced specifically for your organisation |

NuGet reads it as an ordinary prerelease version — which is why it must be
pinned exactly, and why "update" prompts will try to move you off it.

---

## Questions

If you get stuck, send your security team:

- the output of the Step 2 discovery commands,
- the output of the Step 4 verification command,
- and the error, in full.

That's almost always enough to answer it without a call.
