# Seal Security — start here

Your security team found dependencies in your project with known
vulnerabilities. Seal Security has produced **patched versions of those
dependencies** — same version, same classes, plus the CVE fixes.

**They are already in your Artifactory**, which your build already resolves
through. You don't download anything, install anything or configure a
repository. You point your build at the patched artifact and rebuild.

**Read one file: the one for your build tool.** Each is a complete
step-by-step walkthrough. You don't need anything else in this folder.

| Your project has... | Open this |
|---|---|
| `pom.xml` | **`DEVELOPER-GUIDE-MAVEN.md`** |
| `build.gradle` and `gradlew.bat` | **`DEVELOPER-GUIDE-GRADLE.md`** |
| `package.json` | **`DEVELOPER-GUIDE-NPM.md`** |
| `packages.config`, or a `.csproj` referencing jQuery or Ember | **`DEVELOPER-GUIDE-NUGET.md`** |
| `go.mod` | **`DEVELOPER-GUIDE-GO.md`** |

If your project has more than one (a .NET service with a jQuery frontend, say),
work through each guide separately — they don't interfere.

---

## How you'll recognise a patched package

**Java is the odd one out.** The patched jars are published under a **different
group**, at the version you already use. Everything else keeps its name and
changes only the version:

| Ecosystem | Before | After |
|---|---|---|
| Maven / Gradle | `log4j:log4j:1.2.17` | `seal.sp2.log4j:log4j:1.2.17` |
| npm | `ip@1.1.5` | `ip@1.1.5-sp3` |
| NuGet | `jQuery 3.3.1` | `jQuery 3.3.1-sp1p1` |
| Go | `v1.6.4` | `v1.6.4-sp1` |

That difference matters more than it looks:

- **For Java**, the build tool sees a *different* dependency, not a newer one.
  It will happily put both on the classpath, and the scanner will still find the
  vulnerable one. Removing the old jar is a step you do yourself — with
  `<exclusions>` in Maven, `exclude` in Gradle. Both guides cover it, and both
  have a verification step whose whole job is catching a missed exclusion.
- **For npm, NuGet and Go**, the suffix is read as a *prerelease*, which sorts
  **below** the plain version. Anything that offers to "update" the package will
  offer to take you back to the vulnerable one. Each guide tells you how to pin
  it so that can't happen quietly.

---

## What you're signing up for

- **No application code changes.** No `import` changes, no API changes. You edit
  one dependency file and rebuild.
- **Nothing to install.** No new tools, no account, no credentials, no download.
  The patched packages resolve the same way every other dependency already does.
- **Same versions.** The patched build is the version you already use with the
  vulnerability fixed, so nothing else in your dependency tree has to move.
- **~20 minutes**, plus however long your build normally takes.

Your part is the middle step: point the build at the patched package, rebuild,
run your tests, commit. Your security team verifies after your change merges.

---

## What's in this folder

The bundle comes as three downloads — Java, Go, and npm + NuGet. Each one has
this file plus the guides for its own ecosystem, so your download may hold only
some of the files below.

| | |
|---|---|
| `DEVELOPER-GUIDE-MAVEN.md` | Maven walkthrough — 66 patched artifacts |
| `DEVELOPER-GUIDE-GRADLE.md` | Gradle walkthrough — the same 66 artifacts |
| `DEVELOPER-GUIDE-NPM.md` | npm / yarn / pnpm walkthrough — 13 patched packages |
| `DEVELOPER-GUIDE-NUGET.md` | NuGet walkthrough — 2 patched packages (jQuery, Ember) |
| `DEVELOPER-GUIDE-GO.md` | Go modules walkthrough — 17 patched modules |
| `img\` | Screenshots used by the guides |
| `upload\` | Scripts your platform team used to load the packages into Artifactory — nothing for you to run |

Nothing here runs on its own — every step uses your own build tool's commands.
The screenshots are all from Windows.

---

## If something goes wrong

Every guide ends with a **"When something goes wrong"** table covering the
errors people actually hit. Check there first.

One error is worth calling out up front, because it isn't yours to fix: if your
build says it **cannot find** the patched package, it hasn't landed in
Artifactory yet. Retry once with a cache refresh (each guide gives the command),
and if it still fails, tell your security team which coordinate is missing
rather than working around it.

If you're still stuck, send your security team:

- the command you ran,
- its complete output (not a screenshot of part of it),
- your dependency file (`pom.xml`, `build.gradle`, `package.json`,
  `packages.config` or `go.mod`).

That's almost always enough to sort it out in one reply.
